#include <stdio.h>
#include <ctype.h>
#include <string.h>

#define MAX_LEN 100

int main() {
    FILE *fp;
    char line[MAX_LEN];
    int line_num = 0;
    char *keywords[] = {"int", "float", "if", "else", "while", "for", "return", "void"};
    int num_keywords = 8;

    fp = fopen("input.txt", "r");
    if (fp == NULL) {
        printf("Error: Cannot open input file\n");
        return 1;
    }

    printf("Line\tLexeme\t\tToken Type\tToken Value\n");
    printf("-----------------------------------------------\n");

    while (fgets(line, MAX_LEN, fp) != NULL) {
        line_num++;
        int i = 0;
        while (line[i] != '\0') {
            if (isspace(line[i])) { i++; continue; }

            char lexeme[MAX_LEN] = {0};
            int lex_index = 0;

            // Identifiers and Keywords
            if (isalpha(line[i]) || line[i] == '_') {
                while (isalnum(line[i]) || line[i]=='_') {
                    lexeme[lex_index++] = line[i++];
                }
                lexeme[lex_index] = '\0';
                int is_keyword = 0;
                for (int k = 0; k < num_keywords; k++) {
                    if (strcmp(lexeme, keywords[k]) == 0) {
                        is_keyword = 1; break;
                    }
                }
                printf("%d\t%-15s", line_num, lexeme);
                if (is_keyword)
                    printf("KEYWORD\t\t%s\n", lexeme);
                else
                    printf("IDENTIFIER\t%s\n", lexeme);
            }
            // Numbers
            else if (isdigit(line[i])) {
                while (isdigit(line[i])) {
                    lexeme[lex_index++] = line[i++];
                }
                lexeme[lex_index] = '\0';
                printf("%d\t%-15sNUMBER\t\t%s\n", line_num, lexeme, lexeme);
            }
            // Operators
            else if (strchr("+-*/=<>!", line[i])) {
                lexeme[lex_index++] = line[i++];
                if ((lexeme[0]=='=' || lexeme[0]=='<' || lexeme[0]=='>' || lexeme[0]=='!') && line[i]=='=') {
                    lexeme[lex_index++] = line[i++];
                }
                lexeme[lex_index] = '\0';
                printf("%d\t%-15sOPERATOR\t%s\n", line_num, lexeme, lexeme);
            }
            // Symbols
            else if (strchr("(){}[],;.", line[i])) {
                lexeme[lex_index++] = line[i++];
                lexeme[lex_index] = '\0';
                printf("%d\t%-15sSYMBOL\t\t%s\n", line_num, lexeme, lexeme);
            }
            // Unknown Tokens
            else {
                lexeme[lex_index++] = line[i++];
                lexeme[lex_index] = '\0';
                printf("%d\t%-15sUNKNOWN\t%s\n", line_num, lexeme, lexeme);
            }
        }
    }

    fclose(fp);
    return 0;
}
