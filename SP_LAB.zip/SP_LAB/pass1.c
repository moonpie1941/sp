#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_SYMBOLS 100
#define MAX_LITERALS 100
#define MAX_POOLS 10
#define MAX_CODE_LINES 100
#define MAX_OPCODES 50

// Data Structures
typedef struct {
    char symbol[10];
    int address;
} Symbol;

typedef struct {
    char literal[10];
    int address;
} Literal;

typedef struct {
    int start_idx;
} Pool;

typedef struct {
    char mnemonic[10];
    char type[3];  // Instruction type (IS/AD/DL)
    int code;      // Instruction code
} Opcode;

// Global Tables
Symbol symtab[MAX_SYMBOLS];
int symtab_count = 0;
Literal littab[MAX_LITERALS];
int littab_count = 0;
Pool pooltab[MAX_POOLS];
int pooltab_count = 1;
char intermediate_code[MAX_CODE_LINES][50];
int intermediate_count = 0;
Opcode optab[MAX_OPCODES];
int optab_count = 0;
int location_counter = 0;

// Function to add a symbol to the symbol table
void add_symbol(char *symbol, int address) {
    strcpy(symtab[symtab_count].symbol, symbol);
    symtab[symtab_count].address = address;
    symtab_count++;
}

// Function to add a literal to the literal table
void add_literal(char *literal) {
    strcpy(littab[littab_count].literal, literal);
    littab[littab_count].address = -1; // Address will be assigned during LTORG or END
    littab_count++;
}

// Function to load the opcode table from a file
void load_opcode_table(char *filename) {
    FILE *fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Error: Cannot open opcode table file\n");
        exit(1);
    }

    char mnemonic[10], type[3];
    int code;
    while (fscanf(fp, "%s %s %d", mnemonic, type, &code) != EOF) {
        strcpy(optab[optab_count].mnemonic, mnemonic);
        strcpy(optab[optab_count].type, type);
        optab[optab_count].code = code;
        optab_count++;
    }

    fclose(fp);
}

// Function to search for opcode in the opcode table
Opcode* search_opcode(char *mnemonic) {
    for (int i = 0; i < optab_count; i++) {
        if (strcmp(optab[i].mnemonic, mnemonic) == 0) {
            return &optab[i];
        }
    }
    return NULL;
}

// Function to process a single line of assembly code
void process_line(char *line) {
    char token1[10], token2[10], token3[10];
    int i;
    sscanf(line, "%s %s %s", token1, token2, token3);

    if (strcmp(token1, "START") == 0) {
        location_counter = atoi(token2);
        sprintf(intermediate_code[intermediate_count++], "%02d (AD,01) (C,%02d)", location_counter, location_counter);
    } else if (strcmp(token1, "END") == 0) {
        for (i = pooltab[pooltab_count - 1].start_idx; i < littab_count; i++) {
            littab[i].address = location_counter;
            sprintf(intermediate_code[intermediate_count++], "%02d (DL,02) (L,%02d)", location_counter, i + 1);
            location_counter++;
        }
        sprintf(intermediate_code[intermediate_count++], "%02d (AD,02)", location_counter);
    } else if (strcmp(token1, "LTORG") == 0) {
        for (i = pooltab[pooltab_count - 1].start_idx; i < littab_count; i++) {
            littab[i].address = location_counter;
            sprintf(intermediate_code[intermediate_count++], "%02d (DL,02) (L,%02d)", location_counter, i + 1);
            location_counter++;
        }
        pooltab[pooltab_count++].start_idx = littab_count;
        sprintf(intermediate_code[intermediate_count++], "%02d (AD,03)", location_counter);
    } else if (strcmp(token2, "DC") == 0) {
        add_symbol(token1, location_counter);
        sprintf(intermediate_code[intermediate_count++], "%02d (DL,01) (C,%s)", location_counter, token3);
        location_counter++;
    } else if (strcmp(token2, "DS") == 0) {
        add_symbol(token1, location_counter);
        int size = atoi(token3);
        sprintf(intermediate_code[intermediate_count++], "%02d (DL,02) (C,%d)", location_counter, size);
        location_counter += size;
    } else {
        Opcode *opcode = search_opcode(token1);
        if (opcode != NULL) {
            if (token3[0] == '=') {
                add_literal(token3);
                sprintf(intermediate_code[intermediate_count++], "%02d (IS,%02d) (L,%d)", location_counter, opcode->code, littab_count);
            } else {
                sprintf(intermediate_code[intermediate_count++], "%02d (IS,%02d) (S,%d)", location_counter, opcode->code, symtab_count);
            }
            location_counter++;
        } else if (token1[0] == '=') {
            add_literal(token1);
            sprintf(intermediate_code[intermediate_count++], "%02d (L,%d)", location_counter, littab_count);
        } else {
            printf("Error: Undefined instruction %s\n", token1);
        }
    }
}

// Function to display tables in separate files
void display_tables(char *symbol_file, char *literal_file, char *pool_file, char *intermediate_file) {
    // **Symbol Table Section**
    /*
    FILE *symbol_output = fopen(symbol_file, "w");
    if (symbol_output != NULL) {
        fprintf(symbol_output, "Symbol Table:\n");
        for (int i = 0; i < symtab_count; i++) {
            fprintf(symbol_output, "%s\t%d\n", symtab[i].symbol, symtab[i].address);
        }
        fclose(symbol_output);
    } else {
        printf("Error: Cannot open symbol table file\n");
    }
    */

    // **Literal Table Section**
    /*
    FILE *literal_output = fopen(literal_file, "w");
    if (literal_output != NULL) {
        fprintf(literal_output, "Literal Table:\n");
        for (int i = 0; i < littab_count; i++) {
            fprintf(literal_output, "%s\t%d\n", littab[i].literal, littab[i].address);
        }
        fclose(literal_output);
    } else {
        printf("Error: Cannot open literal table file\n");
    }
    */

    // **Pool Table Section**
    /*
    FILE *pool_output = fopen(pool_file, "w");
    if (pool_output != NULL) {
        fprintf(pool_output, "Pool Table:\n");
        for (int i = 0; i < pooltab_count; i++) {
            fprintf(pool_output, "%d\n", pooltab[i].start_idx);
        }
        fclose(pool_output);
    } else {
        printf("Error: Cannot open pool table file\n");
    }
    */

    // **Intermediate Code Section**
    /*
    FILE *intermediate_output = fopen(intermediate_file, "w");
    if (intermediate_output != NULL) {
        fprintf(intermediate_output, "Intermediate Code:\n");
        for (int i = 0; i < intermediate_count; i++) {
            fprintf(intermediate_output, "%s\n", intermediate_code[i]);
        }
        fclose(intermediate_output);
    } else {
        printf("Error: Cannot open intermediate code file\n");
    }
    */
}

int main(int argc, char *argv[]) {
    char input_file[50] = "input.txt";
    char opcode_file[50] = "opcode_table.txt";
    char symbol_file[50] = "symbol_table.txt";
    char literal_file[50] = "literal_table.txt";
    char pool_file[50] = "pool_table.txt";
    char intermediate_file[50] = "intermediate_code.txt";

    if (argc >= 2) strcpy(input_file, argv[1]);
    if (argc >= 3) strcpy(opcode_file, argv[2]);
    if (argc >= 4) strcpy(symbol_file, argv[3]);
    if (argc >= 5) strcpy(literal_file, argv[4]);
    if (argc >= 6) strcpy(pool_file, argv[5]);
    if (argc >= 7) strcpy(intermediate_file, argv[6]);

    load_opcode_table(opcode_file);

    FILE *input = fopen(input_file, "r");
    if (input == NULL) {
        printf("Error: Cannot open input file\n");
        return 1;
    }

    char line[50];
    while (fgets(line, sizeof(line), input) != NULL) {
        process_line(line);
    }
    fclose(input);

    // Generate output files based on uncommented sections
    display_tables(symbol_file, literal_file, pool_file, intermediate_file);

    return 0;
}

/* 
input.txt:

START 200
X DC '10'
Y DS 2
MOVER BREG, ='4'
ADD CREG, ='6'
LTORG
DIV AREG, ='12'
SUB BREG, ='5'
END

opcode_table.txt:

MOVER 01
MOVEM 02
ADD 03
SUB 04
MULT 05
DIV 06
BC 07
COMP 08
PRINT 09
READ 10
*/